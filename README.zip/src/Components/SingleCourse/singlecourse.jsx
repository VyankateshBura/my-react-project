// src/Course.js
import React from 'react';
import './singlecourse.css';

const SingleCourse = ({ course }) => {
  return (
    <div className="course">
      <h3>Module1</h3>      
      <button>select</button>
    </div>
  );
};

export default SingleCourse;